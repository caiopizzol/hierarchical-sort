## Description

This project contains a terminal script capable of sorting a .txt file by its hierarchical properities and metric values

## Usage

Simple usage:

    python sort.py --path 'data/data.txt'


For more information check script --help